# MagicStick editor

A very simple source code editor written in Python 2.x (Python 3.x also supported).


my purpose behind writting this editor was, to polish my own programming skill and also, share my programming skill experience, step by step so that if anyone also want to learn, can follow my journey. I wrote all codes in step by step phase.. means all there are more than 14 folder of this editor code arranged in simple way to show how i develop features of this editor one by one.


In simple, if you also want to polish your skill, just follow.. magicstick_tutorial_series_python_2_7_support_only folder in ascending order.



<div style="box-shadow: 0 5px 18px rgba(0, 0, 0, 0.6);">

<a href="https://surajsinghbisht054.blogspot.com" target="_blank">

![author_profile](https://1.bp.blogspot.com/-PX4oBdjyb14/XbOCqgWpATI/AAAAAAAAELo/-jSsyNSMHmkXGXtw9qCT68qiUNqDE2NcACNcBGAsYHQ/s400/logo.png)

</a>

<p> author : surajsinghbisht054@gmail.com </p>

</div>



- surajsinghbisht054@gmail.com


----

## License

Apache License

